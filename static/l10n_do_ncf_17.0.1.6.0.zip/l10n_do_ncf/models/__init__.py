# -*- coding: utf-8 -*-
from . import ncf_type
from . import ncf_sequence
from . import account_move
from . import res_partner
from . import res_company
from . import license_config
from . import ncf_dashboard
from . import ncf_alert
from . import retention
from . import dgii_reminder
